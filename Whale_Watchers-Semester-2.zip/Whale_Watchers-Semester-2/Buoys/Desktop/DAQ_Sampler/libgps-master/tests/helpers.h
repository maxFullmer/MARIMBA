#ifndef __HELPERS_H__
#define __HELPERS_H__

#define TEST_EPSILON 0.0001

void ck_assert_double_eq(double, double, char *);

#endif

