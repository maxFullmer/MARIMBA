#!/bin/bash

sudo python /home/pi/Desktop/Transmit.py &
