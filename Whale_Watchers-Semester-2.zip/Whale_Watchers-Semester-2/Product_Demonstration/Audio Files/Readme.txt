Sample audio for testing software
