All changes were commented and retained
