Here is all the relivent code for Semester 1 product demonstration.
